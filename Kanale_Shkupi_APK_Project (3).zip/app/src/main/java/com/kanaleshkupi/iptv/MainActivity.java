package com.kanaleshkupi.iptv;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    EditText playlistUrl, search;
    LinearLayout root;
    RecyclerView list;
    ArrayList<Channel> channels = new ArrayList<>();
    ChannelAdapter adapter;

    static class Channel {
        String name, url;
        Channel(String n, String u) { name=n; url=u; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,17,22));
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,16,18,8); root.setBackgroundColor(Color.rgb(16,17,22));
        setContentView(root);

        TextView title = new TextView(this); title.setText("KANALE SHKUPI"); title.setTextColor(Color.WHITE);
        title.setTextSize(26); title.setTypeface(null,1); title.setPadding(0,8,0,4); root.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("TV • FILMA • VIDEO"); subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(13); subtitle.setPadding(0,0,0,18); root.addView(subtitle);

        playlistUrl = new EditText(this); playlistUrl.setSingleLine(true);
        playlistUrl.setHint("Vendos linkun e listës M3U/M3U8");
        playlistUrl.setTextColor(Color.WHITE); playlistUrl.setHintTextColor(Color.GRAY);
        playlistUrl.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        playlistUrl.setPadding(12,4,12,4); root.addView(playlistUrl, new LinearLayout.LayoutParams(-1,54));

        Button load = new Button(this); load.setText("NGARKO LISTËN"); root.addView(load);
        load.setOnClickListener(v -> {
            String url=playlistUrl.getText().toString().trim();
            if (!(url.startsWith("https://") || url.startsWith("http://"))) {
                Toast.makeText(this,"Vendos një link të vlefshëm M3U/M3U8.",Toast.LENGTH_LONG).show(); return;
            }
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(playlistUrl.getWindowToken(),0);
            loadPlaylist(url);
        });

        search = new EditText(this); search.setSingleLine(true); search.setHint("Kërko kanal ose film…");
        search.setTextColor(Color.WHITE); search.setHintTextColor(Color.GRAY); search.setPadding(12,4,12,4);
        root.addView(search, new LinearLayout.LayoutParams(-1,52));

        list = new RecyclerView(this); list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChannelAdapter(); list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1,0,1));
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { adapter.filter(s.toString()); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        showEmpty();
    }

    void showEmpty() {
        channels.clear();
        channels.add(new Channel("Si ta përdorësh", "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"));
        adapter.setData(channels);
    }

    void loadPlaylist(String url) {
        Toast.makeText(this,"Po ngarkohet lista…",Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            ArrayList<Channel> found = new ArrayList<>();
            HttpURLConnection conn=null;
            try {
                conn=(HttpURLConnection)new URL(url).openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(20000);
                conn.setRequestProperty("User-Agent","KanaleShkupi/1.0");
                try(BufferedReader br=new BufferedReader(new InputStreamReader(conn.getInputStream(),"UTF-8"))) {
                    String line, name=null;
                    while((line=br.readLine())!=null) {
                        line=line.trim();
                        if(line.startsWith("#EXTINF")) {
                            int comma=line.lastIndexOf(',');
                            name=comma>=0?line.substring(comma+1).trim():"Kanal";
                            if(name.isEmpty()) name="Kanal";
                        } else if(!line.isEmpty() && !line.startsWith("#") && (line.startsWith("http://")||line.startsWith("https://"))) {
                            found.add(new Channel(name==null?"Video":name,line)); name=null;
                        }
                    }
                }
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(this,"Nuk u lexua lista. Kontrollo linkun dhe internetin.",Toast.LENGTH_LONG).show());
            } finally { if(conn!=null) conn.disconnect(); }
            runOnUiThread(() -> {
                if(!found.isEmpty()) { channels.clear(); channels.addAll(found); adapter.setData(channels);
                    Toast.makeText(this,"U ngarkuan "+found.size()+" video/kanale.",Toast.LENGTH_LONG).show(); }
                else Toast.makeText(this,"Lista është bosh ose formati nuk mbështetet.",Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.Holder> {
        ArrayList<Channel> all=new ArrayList<>(), shown=new ArrayList<>();
        void setData(List<Channel> data) { all=new ArrayList<>(data); shown=new ArrayList<>(data); notifyDataSetChanged(); }
        void filter(String q) { shown.clear(); for(Channel c:all) if(c.name.toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT))) shown.add(c); notifyDataSetChanged(); }
        @Override public Holder onCreateViewHolder(android.view.ViewGroup p,int t) {
            TextView tv=new TextView(MainActivity.this); tv.setTextColor(Color.WHITE); tv.setTextSize(16);
            tv.setPadding(16,18,12,18); tv.setBackgroundColor(Color.rgb(30,32,40));
            RecyclerView.LayoutParams lp=new RecyclerView.LayoutParams(-1,-2); lp.bottomMargin=8; tv.setLayoutParams(lp);
            return new Holder(tv);
        }
        @Override public void onBindViewHolder(Holder h,int pos) {
            Channel c=shown.get(pos); ((TextView)h.itemView).setText("▶   "+c.name);
            h.itemView.setOnClickListener(v->{ Intent i=new Intent(MainActivity.this,PlayerActivity.class); i.putExtra("name",c.name); i.putExtra("url",c.url); startActivity(i); });
        }
        @Override public int getItemCount(){return shown.size();}
        class Holder extends RecyclerView.ViewHolder { Holder(View v){super(v);} }
    }
}
