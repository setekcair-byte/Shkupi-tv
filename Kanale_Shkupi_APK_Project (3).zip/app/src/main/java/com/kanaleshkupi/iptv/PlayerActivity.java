package com.kanaleshkupi.iptv;

import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends AppCompatActivity {
    ExoPlayer player;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        LinearLayout layout=new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); layout.setBackgroundColor(Color.BLACK);
        TextView title=new TextView(this); title.setText(getIntent().getStringExtra("name")); title.setTextColor(Color.WHITE); title.setTextSize(18); title.setPadding(16,16,16,16); layout.addView(title);
        PlayerView pv=new PlayerView(this); pv.setUseController(true); layout.addView(pv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(layout);
        player=new ExoPlayer.Builder(this).build(); pv.setPlayer(player);
        String url=getIntent().getStringExtra("url");
        if(url!=null && (url.startsWith("https://")||url.startsWith("http://"))) {
            player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play();
        } else Toast.makeText(this,"Linku i videos nuk është i vlefshëm.",Toast.LENGTH_LONG).show();
    }
    @Override protected void onStop(){super.onStop(); if(player!=null) player.pause();}
    @Override protected void onDestroy(){super.onDestroy(); if(player!=null){player.release();player=null;}}
}
