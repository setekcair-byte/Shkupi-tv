# Kanale Shkupi — Android IPTV player

Projekt fillestar Android për të luajtur lista M3U/M3U8 që ke të drejtë t'i përdorësh. Nuk përfshin abonime, kanale të paguara ose lista të palicencuara.

## Funksionet
- Ngarkon listën M3U/M3U8 nga një URL HTTP(S)
- Shfaq kanalet/videot dhe kërkon sipas emrit
- Luajtës video me kontrolle bazuar në AndroidX Media3
- Emri i aplikacionit: Kanale Shkupi

## Si të krijosh APK-në
1. Instalo Android Studio në kompjuter.
2. Zgjidh **Open** dhe hap dosjen `KanaleShkupi`.
3. Lejo Gradle Sync të përfundojë; kërkohet internet për shkarkimin e varësive.
4. Nga menuja zgjidh **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK-ja e debug-ut gjendet zakonisht te `app/build/outputs/apk/debug/app-debug.apk`.

## Shënime
- Kërkohet Android SDK 35 dhe JDK 17 (Android Studio mund t'i menaxhojë).
- Përdor vetëm lista dhe transmetime që i zotëron ose për të cilat ke leje.
- Ky është projekt burimor; APK binare nuk është ndërtuar/verifikuar në këtë mjedis.
- Për disa lista, serveri mund të kërkojë hyrje/autorizim ose formati mund të mos mbështetet.
